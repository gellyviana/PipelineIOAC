Projeto Pipeline - Introdução a Organização e Arquitetura de Computadores.

Projeto desenvolvido para disciplina IOAC, com intuito de otimizar a solução de um conjunto de instruções, minorando o tempo de resposta.
A linguagem utilizada é Java, sendo necessário alguma IDE como *NetBeans* ou *Eclipse* para executar o código, como também o próprio terminal do Ubutun.
1-> Abra o terminal: ctrl + alt + t;
2-> Encontre em qual diretório o arquivo com o código fonte de encontra, utlizando o comando *cd* e *ls*;
3-> Entre na pasta *src* e dê o comando para compilar: javac *.java ;
4-> Para executar: java Linha;

Observação: Para adicionar outras instruções basta alterar o "arquivo.txt".